﻿ | FileName                  | Status | Component | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|-----------|----------|----------------|-------------|-------------|---------------|-------------|
 | t.PublishCodeCoverage.dll | Pass   | Sign      | 14KB     | 92.42          | 0.36        | 0.33        | 91.03         | 0           | 
 | TestResultsPublisher.exe  | Pass   | Sign      | 47.5KB   | 92.42          | 0.45        | 0.31        | 91.03         | 0           | 
 | oundation.Core.WebApi.dll | Pass   | Sign      | 102KB    | 81.56          | 0.52        | 0.47        | 80.17         | 0           | 
 | es.TestResults.WebApi.dll | Pass   | Sign      | 184.5KB  | 70.56          | 0.51        | 0.37        | 69.18         | 0           | 
 | nt.PublishTestResults.dll | Pass   | Sign      | 331.5KB  | 81.56          | 0.58        | 0.34        | 80.17         | 0           | 
 | TestManagement.WebApi.dll | Pass   | Sign      | 468.5KB  | 59.07          | 0.64        | 0.4         | 57.68         | 0           | 
 | tudio.Services.Common.dll | Pass   | Sign      | 548.5KB  | 81.56          | 0.65        | 0.35        | 80.17         | 0           | 
 | tudio.Services.WebApi.dll | Pass   | Sign      | 1.71MB   | 81.56          | 0.92        | 0.39        | 80.17         | 0           | 

﻿ | FileName                  | Status | Component | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|-----------|----------|----------------|-------------|-------------|---------------|-------------|
 | osoft.Identity.Client.dll | Pass   | Sign      | 1.61MB   | 30.01          | 0.83        | 0.54        | 25.88         | 0           | 
 | ft.Azure.Storage.File.dll | Pass   | Sign      | 232.38KB | 30.01          | 0.54        | 0.42        | 25.88         | 0           | 
 | .Storage.DataMovement.dll | Pass   | Sign      | 389.92KB | 17.97          | 0.65        | 0.47        | 13.83         | 0           | 
 | .Azure.Storage.Common.dll | Pass   | Sign      | 359.88KB | 17.97          | 0.55        | 0.35        | 13.83         | 0           | 
 | ft.Azure.Storage.Blob.dll | Pass   | Sign      | 408.88KB | 30.01          | 0.65        | 0.24        | 25.88         | 0           | 
 | t.PublishCodeCoverage.dll | Pass   | Sign      | 14KB     | 52.82          | 0.35        | 0.28        | 48.68         | 0           | 
 | TestResultsPublisher.exe  | Pass   | Sign      | 47.5KB   | 494.28         | 0.45        | 0.27        | 490.15        | 0           | 
 | oundation.Core.WebApi.dll | Pass   | Sign      | 102KB    | 86.15          | 0.51        | 0.31        | 82.02         | 0           | 
 | es.TestResults.WebApi.dll | Pass   | Sign      | 184.5KB  | 52.82          | 0.52        | 0.34        | 48.68         | 0           | 
 | nt.PublishTestResults.dll | Pass   | Sign      | 331.5KB  | 107.38         | 0.54        | 0.21        | 103.25        | 0           | 
 | TestManagement.WebApi.dll | Pass   | Sign      | 468.5KB  | 75.22          | 0.64        | 3.3         | 71.09         | 0           | 
 | tudio.Services.Common.dll | Pass   | Sign      | 548.5KB  | 64.14          | 0.65        | 0.34        | 60.01         | 0           | 
 | tudio.Services.WebApi.dll | Pass   | Sign      | 1.71MB   | 118.12         | 0.84        | 0.28        | 113.98        | 0           | 
